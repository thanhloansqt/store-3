;(function($, win){
  'use strict';

  var Share = $.share = (function() {


    function init(){

      smoothScroll();
      toggleMenu();

    }

    
      /* scroll top
    =================================================================== */
    function smoothScroll() {
      $('#back-top').click(function(){
        $('html, body').animate({ scrollTop: 0 }, 'slow');
        return false;
      });
      $(window).on({
        'scroll': function(){
          if ($(window).scrollTop() > 50) {
            $('#back-top').removeClass('hidden_top');
          } else {
            $('#back-top').addClass('hidden_top');
          }
        }
      });
    }


    function toggleMenu() {
      $('.toggle').click(function(){
        $('.sitenav').slideToggle(200);
      });
    }
  
   
    return {
      init: init
    };

  })();

  $(Share.init);

})(jQuery, window);
