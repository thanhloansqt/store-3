;(function($, win){
  'use strict';

  var TopPage = $.toppage = (function() {


    function init(){


      SlideMain();
      SaleProducts();
    }


 
    function SlideMain() {
      var owl = $('.slider-inner');
        owl.owlCarousel({
          items: 1,
          margin: 0,
          nav: false,
          loop: true,
          dots: true,
          autoplay: true,
          responsive: {
            0: {
              items: 1
            },
            600: {
              items: 1
            },
            1000: {
              items: 1
            }
          }
        })
    }

    function SaleProducts() {
      var owl = $('.item-categories');
        owl.owlCarousel({
          loop:true,  
          autoplay:false,
          autoplayTimeout: 8000,
          margin:30,
          nav:true,
          dots:false,
          responsiveClass:true,
            responsive:{
            0:{
                items:2,
                margin:0
            },
            600:{
                items:2
            },
            1000:{
                items:4
            }
          }
        })
    }


    
    return {
      init: init
    };

  })();

  $(TopPage.init);

})(jQuery, window);
