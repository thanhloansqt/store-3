(function($, win){
  "use strict";

  var AsideRaovat = $.asideraovat = (function(){
      var i = 0;

    function init(){
      showItem();
      viewItem();
    }

    function showItem(){
      $(".filter_item .filter_so").each(function(){
        for (i = 0; i < 5; i++) {
          $(this).children().eq(i).addClass("show");
        }
      });
    }

    function viewItem(){
      $(".filter_item").each(function(){
        var $btnOpen = $(this).find('.btn_open');
        var $btnClose = $(this).find('.btn_close');

        $btnClose.hide();

        $btnOpen.on("click", function(e){
          e.preventDefault();
          $(this).parent().parent().find('li').not('.show').fadeIn("slow");
          $(this).hide().next()
           .addClass("show")
           .removeAttr("style");
        });

        $btnClose.on("click", function(e){
          e.preventDefault();
          $(this).hide().prev()
          .addClass("show")
          .removeAttr("style");

          $(this).parent().parent().find('li').removeAttr("style");
          var scrollPosition = parseInt($(this).prev().offset().top) - 300 ;

          $("html, body").animate({
            "scrollTop": scrollPosition + "px"
          },300);
          $(this).hide();
        });
      });
    }

    return {
      init: init
    };

  })();

  $(AsideRaovat.init);

})(jQuery, window);