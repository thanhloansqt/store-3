;(function($, win){
  'use strict';

  var Index = $.index = (function() {


    function init(){
      
      tabChange();
      OtherProduct();
      
    }


    function tabChange() {
      var $btn = $('#tabs span');


      var $content = $(".content-detail .section");

      $btn.on({
        "click": function(){
          var index = $(this).parent().index();
          console.log(index);

          $content.hide();
          $content.eq(index).fadeIn();

          $btn.removeClass("active");
          $(this).addClass("active");

          return false;
        }
      });
      
    }


    function OtherProduct() {
      var owl = $('.product_post');
        owl.owlCarousel({
          margin: 25,
          nav: false,
          loop: true,
          dots: false,
          autoplay:false,
          autoplayTimeout:2000,
          autoplayHoverPause:true,
          responsive: {
            0: {
              items: 2
            },
            600: {
              items: 4
            },
            1000: {
              items: 4
            }
          }
        })
    }
    return {
      init: init
    };

  })();

  $(Index.init);

})(jQuery, window);
