;(function($, win){
  'use strict';

  var TopPage = $.toppage = (function() {


    function init(){


      SlideCommon();
     
    }


 
    function SlideCommon() {
      var owl = $('.slider-inner');
        owl.owlCarousel({
          items: 1,
          margin: 0,
          nav: false,
          loop: true,
          dots: false,
          autoplay: true,
          responsive: {
            0: {
              items: 1
            },
            600: {
              items: 1
            },
            1000: {
              items: 1
            }
          }
        })
    }


    return {
      init: init
    };

  })();

  $(TopPage.init);

})(jQuery, window);
